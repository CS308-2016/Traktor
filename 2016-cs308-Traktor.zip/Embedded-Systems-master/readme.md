<h3>Project Name:</h3><br> 
Tracktor

<h3>Team Members:</h3><br>
1. Aditya Kumar Akash (120050046) (Team Leader)<br>
2. Anurag Shirolkar (120050003)<br>
3. Nishant Kumar Singh (120050043)<br>
4. Shyam JVS (120050052)<br>

<h3>Project Description:</h3> <br>
Tracktor is a system that tracks the user in front of it and orients itself to face the user. It allows the user to keep a device of size varying from that of phone to a tablet on it, allowing user to perform other household works while video calling or watching movie etc. the device.
