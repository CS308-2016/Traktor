Group A 
Names: Aditya Kumar Akash  (120050046)
       Nishant Kumar Singh (120050043)

Group B
Names: Shyam JVS        (120050052)
       Anurag Shirolkar (120050003)


This directory contains documented and commented code for lab experiments of both the groups in the respective folders.
