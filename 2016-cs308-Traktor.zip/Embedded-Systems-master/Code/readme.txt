2016 - CS308  Group X : Project README TEMPLATE 
================================================ 
 
Group Info: 
------------ 
+   Aditya Kumar Akash (120050046)  (Team Leader)
+   Anurag Shirolkar (120050003) 
+   Nishant Kumar Singh (120050043)
+   Shyam JVS (120050053)
 
Extension Of 
------------ 
 
The project is made from scratch. It is not an extension of any other project.
 
Project Description 
------------------- 
 
Tracktor is a system that tracks the user in front of it and orients itself to face the user. It allows the user to keep device of size varying from that of phone to a tablet on it, allowing user to perform other household works while video calling or watching movie etc. the device.  
 
Technologies Used 
------------------- 
 
Following technologies have been used in the project 
 
+   Python 2.7 
+   OpenCV 
+   Raspbian
+   Raspberry Pi
    
 
 
Installation Instructions 
========================= 
 
The user doesn't need to install any softwares on the system. However the links to the above technologies are -
+   [Python 2.7](https://www.python.org/)
+   [OpenCV](http://opencv.org/)
+   [Raspbian](https://www.raspbian.org/)
 
 
Demonstration Video 
=========================  
+   [Screencast](https://www.youtube.com/watch?v=qWQz7CYZ5Fg)
+   [Working demo](https://www.youtube.com/watch?v=S-oK19eegDg)

References 
=========== 
+   [Python 2.7](https://www.python.org/)
+   [OpenCV](http://opencv.org/)
+   [Raspbian](https://www.raspbian.org/)


